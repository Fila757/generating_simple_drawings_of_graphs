var searchData=
[
  ['neighbors_61',['neighbors',['../class_vizualizer_w_p_f_1_1_graph_coordinates.html#a5d29126f7ee674afea5b21a078eee871',1,'VizualizerWPF::GraphCoordinates']]],
  ['nextdrawing_5fclick_62',['NextDrawing_Click',['../class_vizualizer_w_p_f_1_1_main_window.html#ae067ff6ed31958e8734154f6a4f48cc6',1,'VizualizerWPF::MainWindow']]],
  ['none_63',['None',['../namespace_vizualizer_w_p_f.html#a37105a0b372bc8b780566902cac62bdca6adf97f83acf6453d4a6a4b1070f3754',1,'VizualizerWPF']]]
];
