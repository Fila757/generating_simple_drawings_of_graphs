var searchData=
[
  ['nextdrawing_5fclick_158',['NextDrawing_Click',['../class_vizualizer_w_p_f_1_1_main_window.html#ae067ff6ed31958e8734154f6a4f48cc6',1,'VizualizerWPF::MainWindow']]]
];
