var searchData=
[
  ['app_2examl_2ecs_113',['App.xaml.cs',['../_app_8xaml_8cs.html',1,'']]],
  ['assemblyinfo_2ecs_114',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
