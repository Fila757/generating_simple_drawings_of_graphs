var searchData=
[
  ['vertex_195',['Vertex',['../class_vizualizer_w_p_f_1_1_main_window.html#a6f03d48d2609cc57b087081c7fd38014',1,'VizualizerWPF::MainWindow']]],
  ['vertices_196',['vertices',['../class_vizualizer_w_p_f_1_1_graph_coordinates.html#aecf049a510b1f890671f33ec4225e48a',1,'VizualizerWPF::GraphCoordinates']]]
];
