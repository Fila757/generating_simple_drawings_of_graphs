var searchData=
[
  ['none_209',['None',['../namespace_vizualizer_w_p_f.html#a37105a0b372bc8b780566902cac62bdca6adf97f83acf6453d4a6a4b1070f3754',1,'VizualizerWPF']]]
];
