var searchData=
[
  ['regular_210',['Regular',['../namespace_vizualizer_w_p_f.html#aa95aa3e643b222355230511356c6e640ad2203cb1237cb6460cbad94564e39345',1,'VizualizerWPF']]],
  ['removing_211',['Removing',['../namespace_vizualizer_w_p_f.html#a37105a0b372bc8b780566902cac62bdcae44b66d27df57c4a36aa02b0f04ba8a2',1,'VizualizerWPF']]]
];
