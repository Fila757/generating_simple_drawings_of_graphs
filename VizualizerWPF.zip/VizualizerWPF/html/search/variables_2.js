var searchData=
[
  ['graphcoordinates_183',['graphCoordinates',['../class_vizualizer_w_p_f_1_1_graph_generator.html#a77053f9718ad4394ec0a08d3879c93f8',1,'VizualizerWPF.GraphGenerator.graphCoordinates()'],['../class_vizualizer_w_p_f_1_1_main_window.html#acdde361eecb375d8f24f1fe360d72c4c',1,'VizualizerWPF.MainWindow.graphCoordinates()']]],
  ['graphgenerator_184',['graphGenerator',['../class_vizualizer_w_p_f_1_1_main_window.html#af285bb6a4ea3d9c6b7e83646afbe518c',1,'VizualizerWPF::MainWindow']]]
];
