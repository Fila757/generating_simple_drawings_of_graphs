
Generating reference datasets using original https://github.com/mapbox/delaunator

## Usage

```
npm i
./index.js ../test/test-files/playgrounds-1356-epsg-3857.geojson ../test/test-files/playgrounds-1356-triangles.json
```
