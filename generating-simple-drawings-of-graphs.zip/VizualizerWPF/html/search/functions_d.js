var searchData=
[
  ['scale_167',['Scale',['../class_vizualizer_w_p_f_1_1_point_extensions.html#ae5f9c3569df8106cb876b9e7759678da',1,'VizualizerWPF::PointExtensions']]],
  ['selectonlyoneoption_168',['SelectOnlyOneOption',['../class_vizualizer_w_p_f_1_1_main_window.html#ad01d5c39c7feac23b712c3e8531edcda',1,'VizualizerWPF::MainWindow']]],
  ['sortfromstarttoend_169',['SortFromStartToEnd',['../class_vizualizer_w_p_f_1_1_graph_generator.html#a2cfab342ba0298f7f14bdf6d5411a860',1,'VizualizerWPF::GraphGenerator']]],
  ['substract_170',['Substract',['../class_vizualizer_w_p_f_1_1_point_extensions.html#ac1871c738001150f672da44384dff7df',1,'VizualizerWPF::PointExtensions']]]
];
